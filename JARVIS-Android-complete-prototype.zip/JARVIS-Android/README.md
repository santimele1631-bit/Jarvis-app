# JARVIS para Android — prototipo 0.1

Aplicación Android nativa en Kotlin + Jetpack Compose. Usa la API REST de Gemini, reconocimiento de voz de Android y Text-to-Speech del dispositivo.

## Requisitos
- Android Studio reciente
- JDK 17
- Android 8.0 o superior (API 26)
- Conexión a internet
- API Key de Gemini

## Abrir y ejecutar
1. Descomprime el proyecto.
2. Abre la carpeta `JARVIS-Android` desde Android Studio.
3. Espera a que Gradle sincronice.
4. Conecta un dispositivo Android o inicia un emulador.
5. Ejecuta la configuración `app`.
6. En JARVIS, abre Configuración e introduce tu API Key y el modelo habilitado en tu cuenta.

## Voz
- El micrófono usa `SpeechRecognizer` del sistema.
- La salida de voz usa el motor Text-to-Speech instalado en Android.
- El idioma inicial es es-MX. La disponibilidad depende del dispositivo y sus paquetes de voz.

## Seguridad
La clave se guarda cifrada localmente, pero una aplicación cliente no puede proteger completamente una clave frente a un dispositivo comprometido o ingeniería inversa. Para distribuir la app a otras personas, no incrustes una clave compartida: utiliza un backend propio o Firebase AI Logic con App Check y restricciones adecuadas. No compartas tu API Key en chats, capturas ni repositorios.

## Estado real del prototipo
Incluye chat Gemini, voz pulsar-para-hablar, TTS, historial local limitado, configuración de modelo y almacenamiento cifrado de la clave.
Todavía NO incluye palabra de activación permanente, ejecución real de comandos del sistema, calendario, notificaciones programadas, escucha continua, streaming de voz ni agente autónomo. Esas funciones requieren módulos y permisos adicionales; no se deben simular como si ya funcionaran.

## Solución de problemas
- `HTTP 400`: revisa el nombre de modelo y el formato de la petición.
- `HTTP 403`: revisa que la API Key esté habilitada para Gemini y sus restricciones.
- No escucha: concede permiso de micrófono y comprueba que el servicio de reconocimiento de voz esté disponible.
- No habla: revisa el motor TTS y descarga una voz en español desde los ajustes de Android.


## Acciones Android locales (prototipo)
Se añadió `AndroidActionRouter.kt`. Reconoce algunos comandos explícitos en español:
- "abre YouTube"
- "busca en YouTube videos de ... "
- "busca en Google ... "
- "busca en Maps ... "
- "pon una alarma a las 7:30 am" (abre la interfaz del Reloj para confirmar)
- "crea un evento ... " / "añade al calendario ..." (abre un formulario de calendario prellenado; el usuario revisa y guarda)
- "abre Gmail / Google Drive / Google Calendar / Google Keep / Google Fotos"

Estas acciones usan intents y enlaces oficiales. La disponibilidad depende de las aplicaciones instaladas y del dispositivo. El prototipo no obtiene acceso directo a cuentas, no lee correos, no consulta eventos existentes y no guarda alarmas/eventos en segundo plano sin interacción del usuario.


## Sistema de agentes (primer prototipo)
- Gemini recibe la solicitud y devuelve un plan JSON con hasta cuatro pasos.
- La app muestra el plan en un diálogo de confirmación antes de ejecutar.
- Cada paso se valida de nuevo a través de `AndroidActionRouter`; no se ejecutan nombres de herramientas arbitrarios devueltos por el modelo.
- Acciones actualmente permitidas: abrir/buscar en YouTube, Google y Maps; abrir algunas apps web de Google; abrir el formulario del Reloj para una alarma; abrir un formulario de Calendar para un evento.
- Si la acción no está soportada o faltan datos, el planificador debe responder sin acciones.

Limitaciones: todavía no hay ejecución de recordatorios en segundo plano, acceso OAuth a cuentas Google/Microsoft, lectura de correo/calendario, reproducción/pausa de medios, automatización arbitraria de otras apps ni ejecución autónoma sin confirmación. Al abrir varios destinos externos en secuencia, Android puede cambiar de aplicación; por eso este prototipo está pensado para planes cortos. Revisa siempre los datos en las apps de destino.


## Generación de PowerPoint desde Android
Se añadió un selector de Excel y un flujo para guardar el PPTX:
1. Despliega `office_backend` en un servidor HTTPS propio.
2. Instala dependencias de `office_backend/requirements.txt` y ejecuta `uvicorn main:app --host 0.0.0.0 --port 8000` detrás de un proxy TLS.
3. En Ajustes de JARVIS configura el endpoint HTTPS (sin `/` final).
4. Pulsa el clip, selecciona un `.xlsx`, escribe el tema y genera el PowerPoint.
5. Android pedirá dónde guardar el `.pptx`.

No uses un endpoint HTTP público: la API Key Gemini viaja en un encabezado y debe ir cifrada en tránsito. Para producción, reemplaza el envío de la API Key del dispositivo por autenticación propia y un gestor de secretos en servidor.


## Agentes especializados
`AgentRegistry.kt` clasifica las acciones propuestas por Gemini en cinco roles visibles: Research, Office, Android, Personal y Web. Es una capa de organización sobre un único modelo Gemini, no cinco modelos separados ni procesos autónomos. La ejecución sigue limitada a las acciones implementadas y al diálogo de confirmación.

## Límites de seguridad y funcionamiento
- No hay escucha permanente ni activación "Hey JARVIS". El micrófono se activa al pulsar el botón y usa el reconocedor del sistema.
- No hay acceso OAuth a Gmail/Drive/Calendar, lectura de contenido privado ni control arbitrario de apps.
- Alarmas y eventos abren formularios de Android para que el usuario confirme; el prototipo no agenda tareas silenciosamente.
- Las búsquedas de YouTube/Google/Maps abren enlaces y no extraen ni resumen automáticamente el contenido de los resultados.
- El selector de Excel acepta `.xlsx`; el backend genera un `.pptx` si está desplegado y configurado.
- El contenido de IA, biografías, referencias e imágenes debe revisarse antes de entregar o publicar.
