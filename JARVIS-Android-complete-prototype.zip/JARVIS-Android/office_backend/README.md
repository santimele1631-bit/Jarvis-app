# JARVIS Office backend (prototype)

This optional Python service adds Excel-to-PowerPoint generation to the Android JARVIS project.

## What it does
- Accepts `.xlsx` / `.xlsm` files.
- Extracts cell values from workbook sheets.
- Sends the topic and extracted data to Gemini for slide content.
- Creates a `.pptx` presentation.
- Searches Wikimedia Commons for relevant images and includes basic attribution text when an image is inserted.

## Run locally
```bash
cd office_backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

## API
`POST /v1/presentations` as multipart form:
- `topic`: required subject
- `model`: optional Gemini model identifier
- `slide_count`: 4–18
- `excel`: optional `.xlsx` or `.xlsm` file
- Header `X-Jarvis-Gemini-Key`: Gemini API key

`GET /health` checks the service.

## Important limitations
- This is a backend prototype; the Android screen does not yet contain the Excel picker or connect to this endpoint.
- The service should be deployed behind HTTPS with authentication, rate limits, file-size limits, and request logging controls before remote use.
- Do not expose a shared Gemini key in a public client app. For production, move API credentials to a protected server-side secret store.
- Wikimedia Commons results have varying licenses. Review each image's individual license and attribution requirements before publishing a presentation. The generated slide shows basic attribution, but this is not a substitute for license review.
- Gemini-generated biographies and claims must be fact-checked. The model is instructed not to invent citations, but output still needs human review.
- Excel formulas are read as cached values; the backend does not calculate formulas.
- `.xls` legacy workbooks are not supported in this prototype.
