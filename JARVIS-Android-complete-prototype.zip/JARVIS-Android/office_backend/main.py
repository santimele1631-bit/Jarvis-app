import io
import json
import os
import re
from typing import Any

import httpx
from fastapi import FastAPI, File, Form, Header, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from openpyxl import load_workbook
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Inches, Pt

app = FastAPI(title="JARVIS Office", version="0.1.0")

GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models"

def read_excel(data: bytes) -> str:
    try:
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception as exc:
        raise HTTPException(400, f"No pude leer el archivo Excel: {exc}")
    sections = []
    for ws in wb.worksheets:
        rows = []
        for row in ws.iter_rows(values_only=True):
            vals = [str(v) if v is not None else "" for v in row]
            if any(v.strip() for v in vals):
                rows.append(" | ".join(vals))
            if len(rows) >= 80:
                rows.append("[Hoja truncada a 80 filas]")
                break
        if rows:
            sections.append(f"HOJA: {ws.title}\n" + "\n".join(rows))
    wb.close()
    return "\n\n".join(sections)[:18000] or "El libro no contiene datos visibles."

async def ask_gemini(api_key: str, model: str, topic: str, workbook: str, slides: int) -> dict[str, Any]:
    prompt = f"""
Crea una presentación educativa en español de {slides} diapositivas sobre: {topic}.
Usa estos datos de Excel cuando sean relevantes. No inventes cifras del archivo:
{workbook}

Si el tema incluye una persona, incluye una biografía breve, fechas verificables,
aportaciones y contexto histórico. Propón imágenes apropiadas mediante búsquedas
de Wikimedia Commons. Devuelve SOLO JSON válido con esta estructura:
{{
 "title":"...",
 "subtitle":"...",
 "slides":[
   {{"title":"...", "bullets":["..."], "image_query":"..."}}
 ],
 "conclusion":"...",
 "sources":[{{"title":"...", "url":"..."}}]
}}
Entre 3 y 5 bullets breves por diapositiva. Incluye una diapositiva de biografía
cuando corresponda y una de fuentes. No inventes fuentes ni URLs; si no sabes una,
deja sources vacío y señala que hace falta verificarla.
"""
    url = f"{GEMINI_BASE}/{model}:generateContent"
    body = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.35, "responseMimeType": "application/json"}
    }
    async with httpx.AsyncClient(timeout=75) as client:
        response = await client.post(url, headers={"x-goog-api-key": api_key}, json=body)
    if response.status_code != 200:
        raise HTTPException(response.status_code, "Gemini no pudo generar el contenido. Revisa modelo y API Key.")
    try:
        text = response.json()["candidates"][0]["content"]["parts"][0]["text"]
        return json.loads(text)
    except Exception:
        raise HTTPException(502, "Gemini devolvió una respuesta que no pude interpretar como JSON.")

async def commons_image(query: str):
    if not query:
        return None
    params = {
        "action": "query", "generator": "search", "gsrsearch": f"filetype:bitmap {query}",
        "gsrnamespace": 6, "gsrlimit": 1, "prop": "imageinfo",
        "iiprop": "url|extmetadata", "iiurlwidth": 1200, "format": "json"
    }
    headers = {"User-Agent": "JARVISOffice/0.1 (educational presentation tool)"}
    async with httpx.AsyncClient(timeout=20, headers=headers) as client:
        r = await client.get("https://commons.wikimedia.org/w/api.php", params=params)
        r.raise_for_status()
        pages = r.json().get("query", {}).get("pages", {})
        if not pages:
            return None
        item = next(iter(pages.values()))
        info = item.get("imageinfo", [{}])[0]
        meta = info.get("extmetadata", {})
        return {
            "url": info.get("thumburl") or info.get("url"),
            "title": item.get("title", ""),
            "license": meta.get("LicenseShortName", {}).get("value", "Consultar licencia"),
            "artist": meta.get("Artist", {}).get("value", "Autor no indicado"),
            "description": meta.get("ImageDescription", {}).get("value", "")
        }

async def fetch_image(url: str):
    if not url:
        return None
    async with httpx.AsyncClient(timeout=25, follow_redirects=True) as client:
        r = await client.get(url, headers={"User-Agent": "JARVISOffice/0.1"})
        if r.status_code != 200 or not r.headers.get("content-type", "").startswith("image/"):
            return None
        return r.content

def add_text(slide, x, y, w, h, text, size, color, bold=False):
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = box.text_frame
    tf.word_wrap = True
    tf.margin_left = Inches(0.05)
    tf.margin_right = Inches(0.05)
    tf.margin_top = Inches(0.03)
    p = tf.paragraphs[0]
    p.text = text
    p.font.name = "Aptos"
    p.font.size = Pt(size)
    p.font.bold = bold
    p.font.color.rgb = RGBColor(*color)
    return box

async def build_presentation(data: dict[str, Any]) -> bytes:
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    navy = (7, 18, 34)
    cyan = (89, 211, 255)
    white = (240, 248, 255)

    # Cover
    slide = prs.slides.add_slide(blank)
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = RGBColor(*navy)
    add_text(slide, 0.8, 1.8, 11.8, 1.2, data.get("title", "Exposición"), 34, cyan, True)
    add_text(slide, 0.85, 3.1, 11.5, 1.0, data.get("subtitle", "Presentación creada con JARVIS"), 20, white)

    for item in data.get("slides", [])[:18]:
        slide = prs.slides.add_slide(blank)
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = RGBColor(*navy)
        add_text(slide, 0.65, 0.45, 12, 0.65, item.get("title", "Tema"), 27, cyan, True)
        bullets = item.get("bullets", [])
        body = "\n".join("• " + str(b) for b in bullets[:7])
        add_text(slide, 0.8, 1.45, 7.0, 5.3, body, 19, white)
        image_meta = await commons_image(item.get("image_query", ""))
        if image_meta:
            image_bytes = await fetch_image(image_meta.get("url"))
            if image_bytes:
                try:
                    slide.shapes.add_picture(io.BytesIO(image_bytes), Inches(8.15), Inches(1.55),
                                             width=Inches(4.45), height=Inches(3.5))
                    credit = f"{image_meta['title']} | {image_meta['license']} | {image_meta['artist']}"
                    add_text(slide, 8.15, 5.15, 4.45, 0.9, credit[:220], 8, (180, 202, 220))
                except Exception:
                    pass

    conclusion = prs.slides.add_slide(blank)
    conclusion.background.fill.solid()
    conclusion.background.fill.fore_color.rgb = RGBColor(*navy)
    add_text(conclusion, 0.7, 0.55, 12, 0.7, "Conclusión", 30, cyan, True)
    add_text(conclusion, 0.85, 1.65, 11.5, 4.8, data.get("conclusion", "Fin de la exposición."), 21, white)

    sources = data.get("sources", [])
    if sources:
        slide = prs.slides.add_slide(blank)
        slide.background.fill.solid()
        slide.background.fill.fore_color.rgb = RGBColor(*navy)
        add_text(slide, 0.7, 0.55, 12, 0.7, "Fuentes para verificar", 28, cyan, True)
        src_text = "\n".join(f"• {s.get('title','Fuente')}: {s.get('url','')}" for s in sources[:12])
        add_text(slide, 0.85, 1.5, 11.5, 5.4, src_text, 13, white)

    out = io.BytesIO()
    prs.save(out)
    return out.getvalue()

@app.post("/v1/presentations")
async def create_presentation(
    topic: str = Form(...),
    model: str = Form("gemini-2.0-flash"),
    slide_count: int = Form(8),
    excel: UploadFile | None = File(None),
    x_jarvis_gemini_key: str | None = Header(None)
):
    if not x_jarvis_gemini_key:
        raise HTTPException(401, "Falta la API Key en el encabezado X-Jarvis-Gemini-Key.")
    if not 4 <= slide_count <= 18:
        raise HTTPException(400, "El número de diapositivas debe estar entre 4 y 18.")
    workbook = "No se adjuntó archivo Excel."
    if excel:
        if not excel.filename.lower().endswith((".xlsx", ".xlsm")):
            raise HTTPException(400, "Por ahora se aceptan archivos .xlsx o .xlsm.")
        workbook = read_excel(await excel.read())
    content = await ask_gemini(x_jarvis_gemini_key, model, topic, workbook, slide_count)
    pptx = await build_presentation(content)
    filename = re.sub(r"[^a-zA-Z0-9_-]+", "_", topic)[:50] or "jarvis_presentation"
    return StreamingResponse(
        io.BytesIO(pptx),
        media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",
        headers={"Content-Disposition": f'attachment; filename="{filename}.pptx"'}
    )

@app.get("/health")
def health():
    return {"status": "ok", "service": "JARVIS Office"}
