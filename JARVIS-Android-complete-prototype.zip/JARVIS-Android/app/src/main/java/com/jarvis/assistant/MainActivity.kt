package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.Locale
import android.net.Uri

data class ChatMessage(val text: String, val fromJarvis: Boolean)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private var onSpeechResult: ((String) -> Unit)? = null
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            JarvisScreen(
                api = GeminiClient(this),
                onSpeak = { speak(it) },
                onListen = { callback ->
                    onSpeechResult = callback
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) startListening()
                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            )
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) onSpeechResult?.invoke(text)
                }
                override fun onError(error: Int) {}
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer.startListening(intent)
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("es", "MX")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisScreen(api: GeminiClient, onSpeak: (String) -> Unit, onListen: ((String) -> Unit) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { SecurePrefs(context) }
    var apiKey by remember { mutableStateOf(prefs.getApiKey()) }
    var model by remember { mutableStateOf(prefs.getModel()) }
    var officeEndpoint by remember { mutableStateOf(prefs.getOfficeEndpoint()) }
    var officeTopic by remember { mutableStateOf("") }
    var selectedExcel by remember { mutableStateOf<Uri?>(null) }
    var showOfficeDialog by remember { mutableStateOf(false) }
    var officeBusy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(apiKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("SISTEMA EN ESPERA") }
    var pendingPlan by remember { mutableStateOf<AgentPlan?>(null) }
    val messages = remember { mutableStateListOf(ChatMessage("JARVIS en línea. Configura tu API Key de Gemini para comenzar.", true)) }
    val scope = rememberCoroutineScope()
    val history = remember { LocalMemory(context) }
    val actionRouter = remember { AndroidActionRouter(context) }
    val officeClient = remember { OfficeClient() }
    var pendingPptx by remember { mutableStateOf<ByteArray?>(null) }
    val excelPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        selectedExcel = uri
        if (uri != null) showOfficeDialog = true
    }
    val pptxSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.presentationml.presentation")
    ) { uri ->
        val bytes = pendingPptx
        if (uri != null && bytes != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw IllegalStateException("No pude guardar el archivo.")
            }.onSuccess {
                messages.add(ChatMessage("Presentación guardada correctamente.", true))
            }.onFailure {
                messages.add(ChatMessage("Error al guardar: ${it.message}", true))
            }
        }
        pendingPptx = null
    }

    fun sendMessage(raw: String) {
        val prompt = raw.trim()
        if (prompt.isEmpty() || busy) return
        if (apiKey.isBlank()) { showSettings = true; return }
        messages.add(ChatMessage(prompt, false))
        history.add("user", prompt)
        input = ""
        // Plan first: Gemini may propose only allowlisted Android intents.
        busy = true
        status = "PLANIFICANDO"
        scope.launch {
            try {
                val plan = api.plan(apiKey, model, prompt, history.recentContext())
                if (plan.steps.isNotEmpty()) {
                    pendingPlan = plan
                    status = "ESPERANDO CONFIRMACIÓN"
                    val spoken = "He preparado ${plan.steps.size} acciones. Revisa el plan y confirma antes de ejecutarlo."
                    messages.add(ChatMessage(spoken, true))
                    onSpeak(spoken)
                } else {
                    val answer = plan.reply.ifBlank { api.generate(apiKey, model, history.recentContext()) }
                    messages.add(ChatMessage(answer, true))
                    history.add("assistant", answer)
                    onSpeak(answer)
                    status = "EN LÍNEA"
                }
            } catch (e: Exception) {
                val error = "No pude completar la solicitud: ${e.message ?: "error desconocido"}"
                messages.add(ChatMessage(error, true))
                status = "ERROR DE CONEXIÓN"
            } finally { busy = false }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF35C8FF),
        background = Color(0xFF050B14),
        surface = Color(0xFF0B1726)
    )) {
        Scaffold(containerColor = Color(0xFF050B14), topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("J.A.R.V.I.S.", color = Color(0xFF8DE5FF), fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text(status, color = Color(0xFF6A9DB5), fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                },
                actions = { IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Default.Settings, contentDescription = "Configuración", tint = Color(0xFF8DE5FF))
                } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF071321))
            )
        }, bottomBar = {
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF071321)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = {
                    selectedExcel = null
                    showOfficeDialog = true
                }) {
                    Icon(Icons.Default.Description, contentDescription = "Crear exposición", tint = Color(0xFF55D8FF))
                }
                IconButton(onClick = { excelPicker.launch(arrayOf(
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )) }) {
                    Icon(Icons.Default.AttachFile, contentDescription = "Adjuntar Excel", tint = Color(0xFF55D8FF))
                }
                IconButton(onClick = { onListen { heard -> sendMessage(heard) } }) {
                    Icon(Icons.Default.Mic, contentDescription = "Hablar", tint = Color(0xFF55D8FF))
                }
                Box(Modifier.weight(1f).background(Color(0xFF10243A), RoundedCornerShape(18.dp)).padding(13.dp)) {
                    if (input.isEmpty()) Text("Escribe a JARVIS...", color = Color.Gray)
                    BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White))
                }
                IconButton(onClick = { sendMessage(input) }, enabled = !busy) {
                    Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color(0xFF55D8FF))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(
                Brush.verticalGradient(listOf(Color(0xFF071321), Color(0xFF03070D)))
            )) {
                Box(Modifier.fillMaxWidth().padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(116.dp).background(Color(0xFF0D2A40), CircleShape), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(88.dp).background(Color(0xFF0B1B2B), CircleShape), contentAlignment = Alignment.Center) {
                            Text(if (busy) "..." else "J", color = Color(0xFF7CE0FF), fontSize = 42.sp, fontWeight = FontWeight.Light)
                        }
                    }
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(messages) { message ->
                        Column(
                            Modifier.fillMaxWidth(),
                            horizontalAlignment = if (message.fromJarvis) Alignment.Start else Alignment.End
                        ) {
                            Text(if (message.fromJarvis) "JARVIS" else "TÚ", color = Color(0xFF55CFF5), fontSize = 10.sp, letterSpacing = 2.sp)
                            Surface(color = if (message.fromJarvis) Color(0xFF10243A) else Color(0xFF12334A), shape = RoundedCornerShape(14.dp)) {
                                Text(message.text, Modifier.padding(12.dp), color = Color(0xFFE5F6FF), fontSize = 14.sp)
                            }
                        }
                    }
                    if (busy) item { Text("JARVIS está procesando...", color = Color(0xFF55CFF5)) }
                }
            }
        }

        if (showOfficeDialog) {
            AlertDialog(
                onDismissRequest = { if (!officeBusy) showOfficeDialog = false },
                title = { Text("Crear exposición") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (selectedExcel != null) "Excel seleccionado. Indica el tema de la presentación." else "Crea una presentación.")
                        OutlinedTextField(
                            value = officeTopic,
                            onValueChange = { officeTopic = it },
                            label = { Text("Tema de la exposición") },
                            placeholder = { Text("Ej. Albert Einstein y sus aportaciones") }
                        )
                        Text("Se generará un PowerPoint. Verifica las biografías, fuentes y licencias de las imágenes antes de entregarlo.", fontSize = 11.sp)
                        if (officeEndpoint.isBlank()) {
                            Text("Configura primero el servidor Office HTTPS en Ajustes.", color = Color(0xFFFFB86B), fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    TextButton(enabled = !officeBusy && officeTopic.isNotBlank() && officeEndpoint.isNotBlank(),
                        onClick = {
                            officeBusy = true
                            scope.launch {
                                try {
                                    val bytes = officeClient.createPresentation(
                                        context, officeEndpoint, apiKey, model, officeTopic, selectedExcel
                                    )
                                    pendingPptx = bytes
                                    showOfficeDialog = false
                                    pptxSaver.launch((officeTopic.trim().take(40).replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "JARVIS_Exposicion" }) + ".pptx")
                                } catch (e: Exception) {
                                    messages.add(ChatMessage("No pude crear la presentación: ${e.message}", true))
                                } finally {
                                    officeBusy = false
                                    selectedExcel = null
                                }
                            }
                        }) { Text(if (officeBusy) "Generando..." else "Generar PowerPoint") }
                },
                dismissButton = {
                    TextButton(enabled = !officeBusy, onClick = {
                        showOfficeDialog = false
                        selectedExcel = null
                    }) { Text("Cancelar") }
                }
            )
        }

        pendingPlan?.let { plan ->
            AlertDialog(
                onDismissRequest = { pendingPlan = null; status = "EN LÍNEA" },
                title = { Text("Confirmar plan de JARVIS") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(plan.summary)
                        Text("Agentes asignados: ${AgentRegistry.labelsFor(plan.steps).joinToString(", ")}",
                            color = Color(0xFF63D9FF), fontSize = 12.sp)
                        plan.steps.forEachIndexed { index, step ->
                            Text("${index + 1}. ${AgentRegistry.forCommand(step).displayName}: $step",
                                color = Color(0xFFB8E9FF))
                        }
                        Text("Son roles coordinados por Gemini, no modelos independientes. Las acciones se limitan a comandos conocidos y requieren confirmación.", fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val approved = pendingPlan
                        pendingPlan = null
                        if (approved != null) {
                            scope.launch {
                                status = "EJECUTANDO PLAN"
                                var completed = 0
                                val results = mutableListOf<String>()
                                for (step in approved.steps) {
                                    val result = actionRouter.tryHandle(step)
                                    if (result.handled) {
                                        completed++
                                        results.add(result.message)
                                    } else {
                                        results.add("Acción no permitida o no soportada: $step")
                                    }
                                }
                                val report = "Plan finalizado: $completed de ${approved.steps.size} acciones aceptadas. " +
                                    results.joinToString(" ")
                                messages.add(ChatMessage(report, true))
                                history.add("assistant", report)
                                onSpeak(report)
                                status = "EN LÍNEA"
                            }
                        }
                    }) { Text("Confirmar y ejecutar") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        pendingPlan = null
                        messages.add(ChatMessage("Plan cancelado. No ejecuté ninguna acción.", true))
                        status = "EN LÍNEA"
                    }) { Text("Cancelar") }
                }
            )
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { if (apiKey.isNotBlank()) showSettings = false },
                title = { Text("Configuración de Gemini") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("API Key (se guarda cifrada en este dispositivo). No la compartas.")
                        OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, label = { Text("Gemini API Key") }, singleLine = true)
                        OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Modelo Gemini") }, singleLine = true)
                        OutlinedTextField(value = officeEndpoint, onValueChange = { officeEndpoint = it }, label = { Text("Servidor Office HTTPS (opcional)") }, singleLine = true)
                        Text("El servidor Office es opcional. Debes desplegar office_backend en un servidor HTTPS propio.", fontSize = 11.sp, color = Color.Gray)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        prefs.save(apiKey.trim(), model.trim().ifBlank { "gemini-2.5-flash" })
                        prefs.saveOfficeEndpoint(officeEndpoint.trim())
                        model = model.trim().ifBlank { "gemini-2.5-flash" }
                        showSettings = false
                    }) { Text("Guardar") }
                },
                dismissButton = { TextButton(onClick = { if (apiKey.isNotBlank()) showSettings = false }) { Text("Cancelar") } }
            )
        }
    }
}
