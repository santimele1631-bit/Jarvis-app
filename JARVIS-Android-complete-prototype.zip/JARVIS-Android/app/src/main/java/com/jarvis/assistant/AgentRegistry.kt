package com.jarvis.assistant

data class AgentRole(
    val id: String,
    val displayName: String,
    val purpose: String
)

object AgentRegistry {
    val roles = listOf(
        AgentRole("research", "Research Agent", "Organiza información, biografías y fuentes para revisión."),
        AgentRole("office", "Office Agent", "Prepara presentaciones y procesa hojas de cálculo mediante el backend Office."),
        AgentRole("android", "Android Agent", "Abre funciones y aplicaciones mediante intents permitidos."),
        AgentRole("personal", "Personal Agent", "Prepara operaciones de calendario y alarmas que Android confirma."),
        AgentRole("web", "Web Agent", "Abre búsquedas web, YouTube y Google Maps.")
    )

    fun forCommand(command: String): AgentRole {
        val c = command.lowercase()
        return when {
            c.contains("youtube") || c.contains("google") || c.contains("maps") -> roles.first { it.id == "web" }
            c.contains("alarma") || c.contains("evento") || c.contains("calendario") -> roles.first { it.id == "personal" }
            c.contains("excel") || c.contains("powerpoint") || c.contains("presentación") -> roles.first { it.id == "office" }
            else -> roles.first { it.id == "android" }
        }
    }

    fun labelsFor(commands: List<String>): List<String> =
        commands.map { forCommand(it).displayName }.distinct()
}
