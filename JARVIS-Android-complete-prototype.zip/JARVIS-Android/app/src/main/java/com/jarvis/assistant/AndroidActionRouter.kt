package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import java.util.Calendar
import java.util.Locale

data class ActionResult(val handled: Boolean, val message: String)

class AndroidActionRouter(private val context: Context) {
    fun tryHandle(raw: String): ActionResult {
        val text = raw.trim()
        val lower = text.lowercase(Locale("es", "MX"))

        // YouTube: open search results in the YouTube app when installed, otherwise browser.
        val youtubeMarkers = listOf("busca en youtube ", "buscar en youtube ", "youtube busca ", "abre youtube y busca ")
        val marker = youtubeMarkers.firstOrNull { lower.startsWith(it) }
        if (marker != null) {
            val query = text.substring(marker.length).trim()
            if (query.isBlank()) return ActionResult(true, "Indícame qué quieres buscar en YouTube.")
            val url = "https://www.youtube.com/results?search_query=" + Uri.encode(query)
            return openUrl(url, "Abriendo YouTube y buscando: $query")
        }
        if (lower == "abre youtube" || lower == "abrir youtube") {
            return openUrl("https://www.youtube.com", "Abriendo YouTube.")
        }

        // Google Search and Maps search shortcuts.
        val googleMarkers = listOf("busca en google ", "buscar en google ", "googlea ")
        val googleMarker = googleMarkers.firstOrNull { lower.startsWith(it) }
        if (googleMarker != null) {
            val query = text.substring(googleMarker.length).trim()
            if (query.isNotBlank()) return openUrl("https://www.google.com/search?q=${Uri.encode(query)}", "Buscando en Google: $query")
        }
        val mapsMarkers = listOf("busca en maps ", "buscar en maps ", "abre maps y busca ")
        val mapsMarker = mapsMarkers.firstOrNull { lower.startsWith(it) }
        if (mapsMarker != null) {
            val query = text.substring(mapsMarker.length).trim()
            if (query.isNotBlank()) return openUrl("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}", "Abriendo Google Maps para: $query")
        }

        // Alarm: ask Android Clock to show its alarm-setting UI.
        if (lower.startsWith("pon una alarma") || lower.startsWith("crea una alarma") ||
            lower.startsWith("configura una alarma") || lower.startsWith("despiértame")) {
            val time = Regex("""(?:a las|para las)\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""", RegexOption.IGNORE_CASE)
                .find(text)
            if (time == null) {
                return ActionResult(true, "¿A qué hora quieres la alarma? Por ejemplo: «pon una alarma a las 7:30 am».")
            }
            var hour = time.groupValues[1].toIntOrNull() ?: 7
            val minute = time.groupValues[2].toIntOrNull() ?: 0
            val meridiem = time.groupValues[3].lowercase()
            if (hour !in 1..12 || minute !in 0..59) return ActionResult(true, "La hora indicada no es válida.")
            if (meridiem == "pm" && hour != 12) hour += 12
            if (meridiem == "am" && hour == 12) hour = 0
            val label = "JARVIS"
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return launch(intent, "Abriendo Reloj para confirmar la alarma de ${"%02d:%02d".format(hour, minute)}.")
        }

        // Calendar event: Android Calendar app opens a prefilled event form for user confirmation.
        if (lower.startsWith("crea un evento") || lower.startsWith("añade al calendario") ||
            lower.startsWith("agrega al calendario") || lower.startsWith("agenda ")) {
            val title = text.substringAfter("evento", "")
                .ifBlank { text.substringAfter("calendario", "").ifBlank { text.removePrefix("agenda ") } }
                .trim().ifBlank { "Evento de JARVIS" }
            val start = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 1); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
            val end = (start.clone() as Calendar).apply { add(Calendar.HOUR_OF_DAY, 1) }
            val intent = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).apply {
                putExtra(CalendarContract.Events.TITLE, title)
                putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.timeInMillis)
                putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end.timeInMillis)
                putExtra(CalendarContract.Events.DESCRIPTION, "Creado desde JARVIS. Revisa fecha y hora antes de guardar.")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            return launch(intent, "Abriendo el calendario con «$title». Revisa la fecha y hora antes de guardar.")
        }

        // Common useful Google destinations.
        val destinations = mapOf(
            "abre gmail" to "https://mail.google.com",
            "abre google drive" to "https://drive.google.com",
            "abre google calendar" to "https://calendar.google.com",
            "abre calendario" to "https://calendar.google.com",
            "abre google keep" to "https://keep.google.com",
            "abre google fotos" to "https://photos.google.com"
        )
        destinations[lower]?.let { return openUrl(it, "Abriendo ${text}.") }

        return ActionResult(false, "")
    }

    private fun openUrl(url: String, message: String): ActionResult {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return launch(intent, message)
    }

    private fun launch(intent: Intent, message: String): ActionResult {
        return try {
            if (intent.resolveActivity(context.packageManager) == null) {
                ActionResult(true, "No encontré una aplicación compatible. Puedes instalar una app compatible o abrir el enlace desde el navegador.")
            } else {
                context.startActivity(intent)
                ActionResult(true, message)
            }
        } catch (_: Exception) {
            ActionResult(true, "Android no permitió abrir esa función. Revisa las aplicaciones predeterminadas y permisos.")
        }
    }
}
