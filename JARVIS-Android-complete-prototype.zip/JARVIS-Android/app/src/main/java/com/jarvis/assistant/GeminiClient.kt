package com.jarvis.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiClient(context: android.content.Context) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun generate(apiKey: String, model: String, conversation: String): String =
        withContext(Dispatchers.IO) {
            require(apiKey.isNotBlank()) { "Falta la API Key." }
            val safeModel = model.trim().ifBlank { "gemini-2.5-flash" }
            val payload = JSONObject().apply {
                put("system_instruction", JSONObject().put("parts", JSONArray().put(
                    JSONObject().put("text",
                        "Eres JARVIS, un asistente personal claro, competente y prudente. " +
                        "Responde en español salvo que el usuario pida otro idioma. " +
                        "No afirmes haber ejecutado acciones en el teléfono si no se han ejecutado realmente. " +
                        "Cuando una acción requiera permisos, explícalo y solicita confirmación.")
                )))
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", conversation)))
                }))
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.7)
                    put("maxOutputTokens", 2048)
                })
            }
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent")
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw IllegalStateException(detail ?: "Gemini respondió HTTP ${response.code}")
                }
                val json = JSONObject(body)
                json.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                    ?.let { parts -> (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") } }
                    ?.takeIf { it.isNotBlank() }
                    ?: throw IllegalStateException("Gemini no devolvió texto.")
            }
        }

    suspend fun plan(apiKey: String, model: String, userRequest: String, context: String): AgentPlan =
        withContext(Dispatchers.IO) {
            val safeModel = model.trim().ifBlank { "gemini-2.5-flash" }
            val instruction = """
Eres el planificador de agentes de JARVIS para Android. Devuelve SOLO JSON válido:
{"summary":"resumen breve","reply":"respuesta breve si no hay acciones","steps":["comando 1","comando 2"]}
Solo puedes proponer comandos que el enrutador Android soporta:
- "abre YouTube"
- "busca en YouTube <consulta>"
- "busca en Google <consulta>"
- "busca en Maps <consulta>"
- "pon una alarma a las HH:MM am/pm"
- "crea un evento <título>" (abre formulario de calendario; no inventes fecha/hora)
- "abre Gmail", "abre Google Drive", "abre Google Calendar", "abre Google Keep", "abre Google Fotos"
No inventes integraciones ni afirmes que una acción ya se realizó.
Si el usuario pide algo no soportado, explica en reply y deja steps vacío.
Si faltan datos necesarios (por ejemplo hora de alarma), pregunta en reply y deja steps vacío.
No programes recordatorios como si estuvieran soportados: solo alarma y formulario de evento.
Máximo 4 pasos. Las acciones externas siempre requerirán confirmación del usuario en la app.
Contexto reciente:
$context

Solicitud actual:
$userRequest
"""
            val payload = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", instruction)))
                }))
                put("generationConfig", JSONObject().apply {
                    put("temperature", 0.1)
                    put("maxOutputTokens", 1200)
                    put("responseMimeType", "application/json")
                })
            }
            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent")
                .addHeader("x-goog-api-key", apiKey)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = runCatching { JSONObject(body).optJSONObject("error")?.optString("message") }.getOrNull()
                    throw IllegalStateException(detail ?: "Gemini respondió HTTP ${response.code}")
                }
                val raw = JSONObject(body).optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
                    ?: throw IllegalStateException("El planificador no devolvió contenido.")
                val json = JSONObject(raw)
                val stepsJson = json.optJSONArray("steps") ?: JSONArray()
                val steps = (0 until stepsJson.length()).map { stepsJson.optString(it) }
                    .filter { it.isNotBlank() }.take(4)
                AgentPlan(
                    summary = json.optString("summary", "JARVIS preparó un plan."),
                    reply = json.optString("reply", "No se requieren acciones."),
                    steps = steps
                )
            }
        }

}
