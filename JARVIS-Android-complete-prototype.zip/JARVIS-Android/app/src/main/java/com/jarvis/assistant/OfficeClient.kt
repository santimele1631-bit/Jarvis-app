package com.jarvis.assistant

import android.content.Context
import android.net.Uri
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class OfficeClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .callTimeout(210, TimeUnit.SECONDS)
        .build()

    suspend fun createPresentation(
        context: Context,
        endpoint: String,
        apiKey: String,
        model: String,
        topic: String,
        excelUri: Uri?,
        slideCount: Int = 8
    ): ByteArray = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        require(endpoint.startsWith("https://")) {
            "El servidor Office debe usar HTTPS para proteger la API Key."
        }
        require(apiKey.isNotBlank()) { "Falta la API Key de Gemini." }
        require(topic.isNotBlank()) { "Escribe el tema de la exposición." }

        val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("topic", topic)
            .addFormDataPart("model", model.ifBlank { "gemini-2.5-flash" })
            .addFormDataPart("slide_count", slideCount.toString())

        if (excelUri != null) {
            val bytes = context.contentResolver.openInputStream(excelUri)?.use { it.readBytes() }
                ?: throw IllegalStateException("No pude leer el archivo seleccionado.")
            require(bytes.size <= 15 * 1024 * 1024) { "El Excel supera el límite local de 15 MB." }
            val name = "datos.xlsx"
            builder.addFormDataPart(
                "excel", name,
                bytes.toRequestBody("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".toMediaType())
            )
        }

        val base = endpoint.trimEnd('/')
        val request = Request.Builder()
            .url("$base/v1/presentations")
            .header("X-Jarvis-Gemini-Key", apiKey)
            .post(builder.build())
            .build()

        http.newCall(request).execute().use { response ->
            val bytes = response.body?.bytes() ?: ByteArray(0)
            if (!response.isSuccessful) {
                val message = runCatching { String(bytes).take(1000) }.getOrDefault("Error del servidor Office")
                throw IllegalStateException("Servidor Office HTTP ${response.code}: $message")
            }
            require(bytes.isNotEmpty()) { "El servidor devolvió un archivo vacío." }
            bytes
        }
    }
}
