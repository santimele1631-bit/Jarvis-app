package com.jarvis.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

class SecurePrefs(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "jarvis_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun getApiKey() = prefs.getString("api_key", "").orEmpty()
    fun getModel() = prefs.getString("model", "gemini-2.5-flash").orEmpty()
    fun getOfficeEndpoint() = prefs.getString("office_endpoint", "").orEmpty()
    fun saveOfficeEndpoint(endpoint: String) {
        prefs.edit().putString("office_endpoint", endpoint.trim()).apply()
    }
    fun save(key: String, model: String) {
        prefs.edit().putString("api_key", key).putString("model", model).apply()
    }
}

class LocalMemory(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis_memory", Context.MODE_PRIVATE)
    @Synchronized fun add(role: String, text: String) {
        val old = runCatching { JSONArray(prefs.getString("history", "[]")) }.getOrElse { JSONArray() }
        old.put(JSONObject().put("role", role).put("text", text.take(5000)))
        val trimmed = JSONArray()
        val start = (old.length() - 24).coerceAtLeast(0)
        for (i in start until old.length()) trimmed.put(old.getJSONObject(i))
        prefs.edit().putString("history", trimmed.toString()).apply()
    }
    fun recentContext(): String {
        val arr = runCatching { JSONArray(prefs.getString("history", "[]")) }.getOrElse { JSONArray() }
        val lines = (0 until arr.length()).map { i ->
            val item = arr.getJSONObject(i)
            "${item.optString("role")}: ${item.optString("text")}"
        }
        return "Conversación reciente:\n" + lines.joinToString("\n") +
            "\nResponde al último mensaje del usuario teniendo en cuenta el contexto."
    }
}
