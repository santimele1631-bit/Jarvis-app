package com.jarvis.assistant

data class AgentPlan(
    val summary: String,
    val reply: String,
    val steps: List<String>
)
